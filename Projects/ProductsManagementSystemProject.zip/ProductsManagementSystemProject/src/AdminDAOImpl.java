

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.pms.pojo.Product;
import com.pms.pojo.User;

public class AdminDAOImpl implements AdminDAO {

	List<User> usr = new ArrayList<>();
	List<Product> pro = new ArrayList<>();
	
	Scanner input = new Scanner(System.in);
	
/*
	
	@Override
	public List<User> viewAllUsers() {
		return usr;
		
	}

	@Override
	public User viewUser(int uid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateUser(int uid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteUser(int uid) {
		// TODO Auto-generated method stub
		
	}

*/
	// =====================================
	
	@Override
	public void addProducts() {
		
	}

	@Override
	public List<Product> viewAllProducts() {
		return pro;
	}

	@Override
	public Product viewProduct(int pid) {
		for(Product p : pro) {
			if(p.getPid() == pid)
				return p;
		}
		return null;
	}

	@Override
	public void deleteProduct(int pid) {
		for(Product p : pro) {
			if(p.getPid() == pid)
				pro.remove(p);
		}
		
	}

	@Override
	public void updateProduct(int pid) {
		for(Product p : pro) {
			if(p.getPid() == pid) {
				int choice = -1;
				do {
				System.out.println("Enter 1 to update name of the product.\nEnter 2 to update quantity of the product.\nEnter 3 to update price of the product.\n Enter 4 to go back");
				choice = input.nextInt();
				
				if(choice == 1) {
					System.out.println("Enter the new name for the product: ");
					p.setPname(input.next());
					break;
				}else if(choice == 2) {
					System.out.println("Enter to update quantity of the product: ");
					p.setQty(input.nextInt());
					break;
				}else if(choice == 3) {
					System.out.println("Enter updated price of the product: ");
					p.setPrice(input.nextDouble());
					break;
				}else if(choice == 4) {
					
				}else
					System.out.println("Invalid number\n please choose between 1 to 4.");
				
				}while (choice !=4);
				
			}// end if
				
		}// end for
	}


}
