package com.pms.details;

import java.util.List;
import java.util.Scanner;

import com.pms.dao.impl.ProductDAOImpl;
import com.pms.pojo.Product;

public class ProductDetails {

	Scanner input = new Scanner(System.in);
	ProductDAOImpl prodaoimpl = new ProductDAOImpl();


	public void productsMenu() {
	
		while (true) {
			System.out.println("***********Welcome to our store*************");
			System.out.println("***********Please choose the option below**********\");");
			System.out.println("************************************");
			System.out.println("             1) Add Products        ");
			System.out.println("             2) View ALL Products   ");
			System.out.println("             3) View Product        ");
			System.out.println("             4) Delete Product      ");
			System.out.println("             5) Update Product      ");
			System.out.println("             6) GoBack              ");
			System.out.println("************************************");

			int choice = input.nextInt();
			switch (choice) {
			case 1:
				prodaoimpl.addProducts();
				productsMenu();
				break;
			case 2:
				List<Product> pro = prodaoimpl.viewALLProducts();
				System.out.println("************************************");
				System.out.println("PID\tPNAME\tPQTY\tPPRICE");
				for (Product p : pro)
					System.out.println(p.getPname() + "\t" + p.getPname() + "\t" + p.getQty() + "\t" + p.getPrice());
				productsMenu();
				break;
			case 3:
				System.out.println("Enter the product number you want ot view: ");
				prodaoimpl.viewProduct(input.nextInt());
				productsMenu();
				break;
			case 4:
				System.out.println("Enter the product number that you want to delete: ");
				prodaoimpl.deleteProduct(input.nextInt());
				productsMenu();
				break;
			case 5:
				System.out.println("Enter the product number that you want to update: ");
				prodaoimpl.updateProduct(input.nextInt());
				break;
			case 6:

				break;
			default:
				System.out.println("Invalid choice!!!\n Please Enter you choice again: ");
				productsMenu();

			}// end switch

		} // end while
	}
}
