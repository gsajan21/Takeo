package com.pms.details;

import java.util.Scanner;

import com.pms.client.ProductClient;
import com.pms.dao.impl.CustomerDAOImpl;
import com.pms.dao.impl.RegistrationDAOImpl;

public class CustomerDetails {

	Scanner input = new Scanner(System.in);
	CustomerDAOImpl cdaoimpl = new CustomerDAOImpl();
	RegistrationDAOImpl rdaoimpl = new RegistrationDAOImpl();
	
	public boolean login() {
		
		System.out.println("Welcome to our Login");
		System.out.println("Enter your Username: ");
		String  uname = input.next();
		System.out.println("Enter you password: ");
		String password = input.next();
		boolean returnedValue = rdaoimpl.verifyUser(uname, password);
		if(returnedValue == true) {
			return true;
		} else
			return false;
	}
	
	public void customerMenu() {
		
		System.out.println("***********Welcome to our Customer Page*************");
		System.out.println("***********Please choose the option below***********");
		System.out.println("*********Please Login to continue...*********");
		
		boolean check = login();
		
		while (check == true) {
			
			System.out.println("************************************");
			System.out.println("             1) View All Products    ");
			System.out.println("             2) View Product          ");
			System.out.println("             3) Buy Product           ");
			System.out.println("             3) Go Back              ");
			System.out.println("************************************");

			int choice = input.nextInt();
			switch (choice) {
			case 1:
				
				customerMenu();
				break;
			case 2:
				
				break;
			case 3:
				ProductClient.main(null);
			default:
				System.out.println("Invalid choice!!!\nPlease choose between 1 to 3.");

			}// end switch

		} // end while
	}
}
