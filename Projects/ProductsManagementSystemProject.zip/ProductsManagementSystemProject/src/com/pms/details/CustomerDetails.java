package com.pms.details;

import java.util.Scanner;

import com.pms.client.ProductClient;
import com.pms.dao.impl.CustomerDAOImpl;
import com.pms.dao.impl.ProductDAOImpl;
import com.pms.dao.impl.RegistrationDAOImpl;

public class CustomerDetails {

	Scanner input = new Scanner(System.in);
	CustomerDAOImpl cdaoimpl = new CustomerDAOImpl();
	RegistrationDAOImpl rdaoimpl = new RegistrationDAOImpl();
	ProductDAOImpl pdaoimpl = new ProductDAOImpl();
	ProductDetails pdetails = new ProductDetails();
	
	public void login() {
		
		System.out.println("Welcome to our Customer Login");
		System.out.println("Enter your Username: ");
		String  uname = input.next();
		System.out.println("Enter you password: ");
		String password = input.next();
		boolean returnedValue = rdaoimpl.verifyUser(uname, password);
		if(returnedValue == true) {
			customerMenu();
		} else
			System.out.println("\n\nInvalid username or password.\n\n");
	}
	public void buyProduct() {
		System.out.println("Enter the product number to buy the product: ");
		pdaoimpl.buyProduct(input.nextInt());
	}
	
	public void customerMenu() {
		System.out.println("***********Welcome to our Customer Page*************");
		System.out.println("***********Please choose the option below***********");
		while (true) {
	
			System.out.println("************************************");
			System.out.println("             1) View All Products    ");
			System.out.println("             2) View Product          ");
			System.out.println("             3) Buy Product           ");
			System.out.println("             4) Go Back              ");
			System.out.println("************************************");

			int choice = input.nextInt();
			switch (choice) {
			case 1:
				pdetails.viewAllProducts();
				customerMenu();
				break;
			case 2:
				pdetails.viewProduct();
				customerMenu();
				break;
			case 3:
				buyProduct();
				customerMenu();
				break;
			case 4:
				ProductClient.main(null);
			default:
				System.out.println("Invalid choice!!!\nPlease choose between 1 to 3.");

			}// end switch

		} // end while
	}
}
