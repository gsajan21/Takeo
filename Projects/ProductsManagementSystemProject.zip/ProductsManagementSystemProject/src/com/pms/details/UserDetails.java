package com.pms.details;

public class UserDetails {

	public void userMenu() {
		
	}
}
