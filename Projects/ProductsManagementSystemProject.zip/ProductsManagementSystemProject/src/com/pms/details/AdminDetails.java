package com.pms.details;

import java.util.List;
import java.util.Scanner;

import com.pms.dao.impl.AdminDAOImpl;
import com.pms.pojo.Product;

public class AdminDetails {
	
	Scanner input = new Scanner(System.in);
	AdminDAOImpl admindaoimpl = new AdminDAOImpl();
	
	public void adminMenu() {
		while (true) {
			System.out.println("***********Welcome to our Admin Page*************");
			System.out.println("***********Please choose the option below********");
			System.out.println("***************************************");
			System.out.println("             1) View ALL Product       ");
			System.out.println("             2) View Product           ");
			System.out.println("             3) Update Product         ");
			System.out.println("             4) Delete Product         ");
			System.out.println("             5) Go Back                ");
			System.out.println("***************************************");

			int choice = input.nextInt();
			switch (choice) {
			case 1:
				List<Product> viewallpro = admindaoimpl.viewAllProducts();
				System.out.println("************************************");
				System.out.println("PID\tPNAME\tPPRICE\tQTY");
				for (Product pro: viewallpro)
					System.out.println(pro.getPid()+"\t" + pro.getPname() +"\t"+ pro.getPrice()+"\t"+pro.getQty());
				adminMenu();
				break;
			case 2:
				System.out.println("Enter the user number you want to view: ");
				admindaoimpl.viewProduct(input.nextInt());
				adminMenu();
				break;
			case 3:
				System.out.println("Enter the product number that you want to update: ");
				admindaoimpl.updateProduct(input.nextInt());
				break;
			case 4:
				System.out.println("Enter the product number that you want to delete: ");
				admindaoimpl.deleteProduct(input.nextInt());
				adminMenu();
				break;
			case 5:
				adminMenu();
				break;
			default:
				System.out.println("Invalid choice!!!\n Please Enter you choice again: ");
				adminMenu();

			}// end switch

		} // end while
	}
}
