package com.pms.details;

import java.util.Scanner;

import com.pms.client.ProductClient;
import com.pms.dao.impl.RegistrationDAOImpl;

public class RegistrationDetails {

	Scanner input = new Scanner(System.in);
	RegistrationDAOImpl rdaoimpl = new RegistrationDAOImpl();
	
	public void registrationMenu() {

		while (true) {
			System.out.println("********************************");
			System.out.println("Welcome to the Registration Page");
			System.out.println("            1) Register         ");
			System.out.println("            2) Login            ");
			System.out.println("            3) Back             ");
			System.out.println("********************************");

			int choice = input.nextInt();
			
			switch (choice) {
			case 1:
				new RegistrationDAOImpl().addUser();
				registrationMenu();
				break;
			case 2:
				new CustomerDetails().login();
				break;
			case 3:
				ProductClient.main(null);
				break;
			default:
				System.out.println("Invlid choice!!!\nPlease choose between 1 to 3");
					
			}// end switch

		} // end while

	}
}
