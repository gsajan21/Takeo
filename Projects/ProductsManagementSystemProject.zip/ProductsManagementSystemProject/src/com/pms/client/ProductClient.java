package com.pms.client;

import java.util.Scanner;

import com.pms.details.CustomerDetails;
import com.pms.details.ProductDetails;
import com.pms.details.RegistrationDetails;


public class ProductClient {

	public static void main(String[] args) {
		
		Scanner input = new Scanner (System.in);
		
		while (true) {
			
		System.out.println("Welcome to Client Application");
		System.out.println("*****************************");
		System.out.println("          1) Admin           ");
		System.out.println("          2) Customer        ");
		System.out.println("          3) Registration    ");
		System.out.println("          4) Exit            ");
		System.out.println("*****************************");
		
		int choice = input.nextInt();
		
		switch(choice) {
		case 1:
			new ProductDetails().productsMenu();
//			ProductClient.main(null);
			break;
		case 2:
			new CustomerDetails().login();
			break;
		case 3:
			new RegistrationDetails().registrationMenu();
			break;
			
		case 4:
			System.exit(0);
			break;
		default:
				System.out.println("Invalid choice!!!\nEnter between 1 to 4.");
		}// end switch
		
		}// end while

	}

}
