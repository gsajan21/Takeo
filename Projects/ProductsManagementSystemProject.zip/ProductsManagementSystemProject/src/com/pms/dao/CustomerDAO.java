package com.pms.dao;

import java.util.List;

import com.pms.pojo.Product;

public interface CustomerDAO{
	
	public List <Product>viewAllProducts();
	public Product viewProduct(int pid);
	public void buyProduct(int pid);

}
