package com.pms.dao;

import java.util.List;

import com.pms.pojo.Product;

public interface ProductDAO {
	
	void addProducts();
	List<Product> viewALLProducts();
	Product viewProduct(int pid);
	void deleteProduct(int pid);
	void updateProduct(int pid);
	void buyProduct(int pid);
	
}
