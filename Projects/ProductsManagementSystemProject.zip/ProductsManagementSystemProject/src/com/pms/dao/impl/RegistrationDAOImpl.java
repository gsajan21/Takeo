package com.pms.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.pms.dao.RegistrationDAO;
import com.pms.pojo.User;

public class RegistrationDAOImpl implements RegistrationDAO{

	Scanner input = new Scanner(System.in);
	static List <User> usrAdd = new ArrayList<>();
	
	@Override
	public void addUser() {

		System.out.println("Enter User ID: ");
		int uid = input.nextInt();
		System.out.println("Enter your first name: ");
		String fname = input.next();
		System.out.println("Enter your last name: ");
		String lname = input.next();
		System.out.println("Enter your email: ");
		String email = input.next();
		System.out.println("Enter your username: ");
		String username = input.next();
		System.out.println("Enter your password: ");
		String password = input.next();

		User usr = new User(uid, fname, lname, email, username, password);
		usrAdd.add(usr);

		System.out.println("Thank you for the Regitration.");
	}

	@Override
	public boolean verifyUser(String uname, String password) {
		boolean flag = false;
		// Debugging 
		for(User u : usrAdd) {
			if(uname.equalsIgnoreCase(u.getUsername()) && password.equals(u.getPassword())) {
				flag = true;
			} // end if
		} // end for
		return flag;
	}

}
