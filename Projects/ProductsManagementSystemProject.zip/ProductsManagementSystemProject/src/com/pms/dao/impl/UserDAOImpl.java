package com.pms.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.pms.dao.UserDAO;
import com.pms.pojo.User;

public class UserDAOImpl implements UserDAO {

	List<User> usrAdd = new ArrayList<>();
	Scanner input = new Scanner(System.in);

	@Override
	public void addUser() {

		System.out.println("Enter User ID: ");
		int uid = input.nextInt();
		System.out.println("Enter your first name: ");
		String fname = input.next();
		System.out.println("Enter your last name: ");
		String lname = input.next();
		System.out.println("Enter your email: ");
		String email = input.next();
		System.out.println("Enter your username: ");
		String username = input.next();
		System.out.println("Enter your password: ");
		String password = input.next();

		User usr = new User(uid, fname, lname, email, username, password);
		usrAdd.add(usr);

		System.out.println("Thank you for the Regitration.");
	}

	@Override
	public List<User> viewAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User viewUser(int uid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateUser(int uid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteUser(int uid) {
		// TODO Auto-generated method stub
		
	}

}
