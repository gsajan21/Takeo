package com.pms.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.pms.dao.CustomerDAO;
import com.pms.pojo.Product;

public class CustomerDAOImpl implements CustomerDAO {

	List<Product> pro = new ArrayList<>();
//	AdminDAOImpl adaoimpl = new AdminDAOImpl();
	ProductDAOImpl pdaoimpl = new ProductDAOImpl();
	Scanner input = new Scanner(System.in);

	@Override
	public List<Product> viewAllProducts() {
		List<Product> l = pdaoimpl.viewALLProducts();
		return l;
	}

	@Override
	public Product viewProduct(int pid) {
		Product p = pdaoimpl.viewProduct(pid);
		return p;
	}

	@Override
	public void buyProduct(int pid) {
		for (Product pro : pro) {
			if (pro.getPid() == pid) {
				int qty = pro.getQty();
				qty -= 1;
				pro.setQty(qty);
				System.out.println("Thank you for your purchase.");
				break;
			} else
				System.out.println("Products doesn't match.");
		}

	}

}
