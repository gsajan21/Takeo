package com.pms.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.pms.dao.ProductDAO;
import com.pms.pojo.Product;

public class ProductDAOImpl implements ProductDAO {

	static List<Product> proAdd = new ArrayList<>();
	Scanner input = new Scanner(System.in);

	@Override
	public void addProducts() {

		System.out.println("Enter PID: ");
		int pid = input.nextInt();
		System.out.println("Enter product name: ");
		String pname = input.next();
		System.out.println("Enter product qty: ");
		int qty = input.nextInt();
		System.out.println("Enter product price: ");
		double price = input.nextInt();

		Product pro = new Product(pid, pname, qty, price);
		proAdd.add(pro);

		System.out.println("Your product added Successfully.");

	}

	@Override
	public List<Product> viewALLProducts() {
		return proAdd;
	}

	@Override
	public Product viewProduct(int pid) {
		for (Product pro : proAdd) {
			if (pro.getPid() == pid)
				return pro;
		}
		return null;
	}

	@Override
	public void deleteProduct(int pid) {

		for (Product pro : proAdd) {
			if (pro.getPid() == pid)
				proAdd.remove(pro);
		}

	}

	@Override
	public void updateProduct(int pid) {
		for (Product pro : proAdd) {
			if (pro.getPid() == pid) {
				int choice = -1;
				do {
					System.out.println(
							"Enter 1 to update name of the product.\nEnter 2 to update quantity of the product.\nEnter 3 to update price of the product.\nEnter 4 to go back");
					choice = input.nextInt();

					if (choice == 1) {
						System.out.println("Enter the new name for the product: ");
						pro.setPname(input.next());

					} else if (choice == 2) {
						System.out.println("Enter to update quantity of the product: ");
						pro.setQty(input.nextInt());

					} else if (choice == 3) {
						System.out.println("Enter updated price of the product: ");
						pro.setPrice(input.nextDouble());

					} else if (choice == 4) {

					} else
						System.out.println("Invalid number\n please choose between 1 to 4.");

				} while (choice != 4);

			} // end if

		} // end for

	}

	@Override
	public void buyProduct(int pid) {
		for (Product pro : proAdd) {
			if (pro.getPid() == pid) {
				int qty = pro.getQty();
				qty -= 1;
				pro.setQty(qty);
				System.out.println("Thank you for your purchase.");
				break;
			} else
				System.out.println("Products doesn't match.");
		}

	}

}
