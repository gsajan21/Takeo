package com.pms.dao;

import java.util.List;

import com.pms.pojo.User;

public interface UserDAO {

	public void addUser();
	public List<User> viewAllUsers();
	public User viewUser(int uid);
	public void updateUser(int uid);
	public void deleteUser(int uid);
	
}
