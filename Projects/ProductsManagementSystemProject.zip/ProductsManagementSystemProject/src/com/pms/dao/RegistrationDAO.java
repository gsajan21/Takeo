package com.pms.dao;

public interface RegistrationDAO {
	
	public void addUser();
	boolean verifyUser(String uname, String password); 

}
