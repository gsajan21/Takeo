

import java.util.List;
import java.util.Scanner;

import com.pms.client.ProductClient;
import com.pms.dao.impl.ProductDAOImpl;
import com.pms.details.ProductDetails;
import com.pms.pojo.Product;

public class AdminDetails {
	
	Scanner input = new Scanner(System.in);
	AdminDAOImpl admindaoimpl = new AdminDAOImpl();
	ProductDetails prod = new ProductDetails();
	public void adminMenu() {
		while (true) {
			System.out.println("***********Welcome to our Admin Page*************");
			System.out.println("***********Please choose the option below********");
			System.out.println("***************************************");
			System.out.println("             1) Add Product            ");
			System.out.println("             2) View ALL Products      ");
			System.out.println("             3) View Product           ");
			System.out.println("             4) Update Product         ");
			System.out.println("             5) Delete Product         ");
			System.out.println("             6) Go Back                ");
			System.out.println("***************************************");

			int choice = input.nextInt();
			switch (choice) {
			case 1:
				new ProductDAOImpl().addProducts();
				break;
			case 2:
				
				adminMenu();
				break;
			case 3:
				System.out.println("Enter the product number you want to view: ");
				admindaoimpl.viewProduct(input.nextInt());
				adminMenu();
				break;
			case 4:
				System.out.println("Enter the product number that you want to update: ");
				admindaoimpl.updateProduct(input.nextInt());
				break;
			case 5:
				System.out.println("Enter the product number that you want to delete: ");
				admindaoimpl.deleteProduct(input.nextInt());
				adminMenu();
				break;
			case 6:
				ProductClient.main(null);
				break;
			default:
				System.out.println("Invalid choice!!!\n Please Enter you choice again: ");
				adminMenu();

			}// end switch

		} // end while
	}
}
