

import java.util.List;

import com.pms.pojo.Product;
//import com.pms.pojo.User;

public interface AdminDAO {

//	public List<User> viewAllUsers();
//	public User viewUser(int uid);
//	public void updateUser(int uid);
//	public void deleteUser(int uid);
	
	public void addProducts();
	public List<Product> viewAllProducts();
	public Product viewProduct(int pid);
	public void deleteProduct(int pid);
	public void updateProduct(int pid);
	
}
